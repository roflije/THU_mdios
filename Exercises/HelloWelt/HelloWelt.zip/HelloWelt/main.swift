//
//  main.swift
//  HelloWelt
//
//  Created by Jeet, Chandan on 22.03.22.
//

import Foundation

print("Hello, World!")

